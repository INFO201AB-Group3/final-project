#install.packages("shinythemes")
#install.packages("alluvial")

library(shiny)
library(dplyr)
#library(tidyr)
#library(modelr)
#library(tidyverse)
#library(MASS)
library(shinythemes)
library(plotly)
#library(DT)
#library(markdown)
library(alluvial)

#lists to make the checkboxes easier to read
year_list = list("2005" = '2005', "2010" = '2010', '2011' = '2011', '2012' = '2012', '2013' = '2013', '2014' = '2014')
level_list = list("2-Year College" = "2-year college", "Bachelors" = "Bachelor's", "Masters" = "Master's", "Doctoral" = "Doctoral", 'Total higher education' = 'Total tertiary')
level_list_sel = list("2-Year College" = "2-year college", "Bachelors" = "Bachelor's", "Masters" = "Master's", "Doctoral" = "Doctoral")
field_list = list("Science, Mathematics and Computing" = "Science, mathematics and computing",
                  "Education" = "Education",
                  "Humanities and Arts" = "Humanities and arts",
                  "Social Sciences, Business and Law" = "Social sciences, business and law",
                  "Engineering, Manufacturing and Construction" = "Engineering, manufacturing and construction",
                  "Agriculture and Veterinary" = "Agriculture and veterinary",
                  "Health and Welfare" = "Health and Welfare",
                  "Services" = "Services")


shinyUI(navbarPage("Analysis of Graduates by Field", theme = shinytheme("superhero"),
  tabPanel('Overview',
   titlePanel('Overview'),
    sidebarLayout(
       
      sidebarPanel(
        
        #checkboxes to choose gender filter
        checkboxGroupInput("sex", label = h3("Gender"), 
                           choices = list("Women" = 'Women', "Men" = "Men"),
                           selected = c("Women", "Men"), inline = TRUE),
        
         #filter by year   
        checkboxGroupInput("year", label = h3("Year"),
                           choices = year_list,
                           selected = year_list, inline = TRUE),
        
        # filter by Education level
        checkboxGroupInput("level", label = h3("Education Level"), 
                           choices = level_list, 
                           selected = level_list_sel, inline = TRUE),
        #filter by field of study
        checkboxGroupInput("field", label = h3("Field of Study"), 
                          choices = field_list, 
                          selected = field_list),
        
        #textbox to use to search for a country
        textInput('country', label=h3("Find a Country"), value = '')
  
      ),
      
      mainPanel(
      
      plotOutput('plot', width = '100%', height = '600px')
      
    ) 
  ) 
)   
)
)
