
library(shiny)
library(dplyr)
library(alluvial)
library(ggplot2)

# this renders the plot and outputs a alluvial plot

# Source files for functions
source('./scripts/buildAlluvial.R')

# Read in OECD data
my.df <- read.csv(file = "./data/OECD_stats.csv")

# Select desired columns
my.df <- my.df %>%  select(Country., Sex, Field, Level.of.education, Year., Value) %>% 
  rename(Country = Country., Year = Year.)

# Start shinyServer
# Returns a bunch of charts and graphs 

shinyServer(function(input, output) { 
   output$plot <- renderPlot({ 
   return(buildAlluvial(my.df, input$sex, input$year, input$level, input$field, input$country))
  })
  
}) 
  


